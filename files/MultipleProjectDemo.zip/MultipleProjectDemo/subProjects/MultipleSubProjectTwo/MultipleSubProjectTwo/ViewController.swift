//
//  ViewController.swift
//  MultipleSubProjectTwo
//
//  Created by liyuanbo on 2023/9/26.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

